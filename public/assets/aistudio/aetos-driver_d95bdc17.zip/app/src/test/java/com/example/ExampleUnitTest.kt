package com.example

import com.example.data.local.FareSettingsEntity
import com.example.engine.FareCalculatorEngine
import com.example.engine.TripMetricParser
import com.example.model.PickupMetric
import com.example.model.ProfitRating
import com.example.model.TripMetric
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testTripMetricParser_arabicTextExtraction() {
        val arabicLines = listOf(
            "الوصول للراكب خلال ٣ دقائق / ١.٢ كم",
            "مسافة الرحلة ٨.٥ كم / ٢٢ دقيقة",
            "السعر المقترح: 45.00 ج.م"
        )

        val (pickup, trip) = TripMetricParser.parseRideDetails(arabicLines)
        val fare = TripMetricParser.extractFareAmount(arabicLines.joinToString(" "))

        assertEquals(1.2, pickup.distanceKm, 0.01)
        assertEquals(3, pickup.durationMinutes)
        assertEquals(8.5, trip.distanceKm, 0.01)
        assertEquals(22, trip.durationMinutes)
        assertEquals(45.00, fare, 0.01)
    }

    @Test
    fun testTripMetricParser_englishTextExtraction() {
        val englishLines = listOf(
            "Pickup: 4 mins away (1.5 km)",
            "Dropoff trip distance: 12.0 km, 28 mins",
            "Offer: $35.50"
        )

        val (pickup, trip) = TripMetricParser.parseRideDetails(englishLines)
        val fare = TripMetricParser.extractFareAmount(englishLines.joinToString(" "))

        assertEquals(1.5, pickup.distanceKm, 0.01)
        assertEquals(4, pickup.durationMinutes)
        assertEquals(12.0, trip.distanceKm, 0.01)
        assertEquals(28, trip.durationMinutes)
        assertEquals(35.50, fare, 0.01)
    }

    @Test
    fun testFareCalculatorEngine_multipliesOnlyTripDistance() {
        val settings = FareSettingsEntity(
            baseFare = 5.00,
            pricePerKm = 2.00,
            pricePerMinute = 0.50,
            minFare = 8.00,
            commissionPercent = 20.0,
            currencySymbol = "$"
        )
        val engine = FareCalculatorEngine(settings)

        val pickup = PickupMetric(distanceKm = 4.0, durationMinutes = 10, rawText = "Pickup 4km")
        val trip = TripMetric(distanceKm = 10.0, durationMinutes = 20, rawText = "Trip 10km")

        // True Fare Formula: base (5) + (tripKm * pricePerKm = 10 * 2 = 20) + (tripMin * pricePerMin = 20 * 0.5 = 10) = 35.0
        // Notice: pickup 4km is NOT in the trip fare!
        val offerFare = 40.00
        val breakdown = engine.calculate(pickup, trip, offerFare, surgeMultiplier = 1.0)

        assertEquals(35.00, breakdown.calculatedTrueFare, 0.01)
        assertEquals(40.00, breakdown.appOfferFare, 0.01)
        assertEquals(5.00, breakdown.difference, 0.01)
        assertEquals(32.00, breakdown.netDriverFare, 0.01) // 40 * 0.8
        assertEquals(ProfitRating.HIGH_PROFIT, breakdown.profitRating)
        assertEquals(4.00, breakdown.ratePerKm, 0.01) // 40 / 10km
    }

    @Test
    fun testFareCalculatorEngine_lowProfitRating() {
        val settings = FareSettingsEntity(
            baseFare = 5.00,
            pricePerKm = 3.00,
            pricePerMinute = 0.20,
            minFare = 10.00
        )
        val engine = FareCalculatorEngine(settings)

        val pickup = PickupMetric(1.0, 2, "pickup")
        val trip = TripMetric(10.0, 25, "trip") // 5 + 30 + 5 = 40.00 true fare

        val lowOfferFare = 25.00 // Underpriced by passenger
        val breakdown = engine.calculate(pickup, trip, lowOfferFare)

        assertEquals(40.00, breakdown.calculatedTrueFare, 0.01)
        assertEquals(ProfitRating.LOW_PROFIT, breakdown.profitRating)
        assertTrue(breakdown.difference < 0.0)
    }
}
