package com.example.engine

import com.example.data.local.FareSettingsEntity
import com.example.model.FareBreakdown
import com.example.model.PickupMetric
import com.example.model.ProfitRating
import com.example.model.TripMetric
import kotlin.math.max
import kotlin.math.roundToInt

class FareCalculatorEngine(
    private val settings: FareSettingsEntity
) {

    /**
     * Strictly computes fare based ONLY on actual trip distance and trip duration.
     * Pickup metrics are calculated independently as driver operational overhead.
     */
    fun calculate(
        pickup: PickupMetric,
        trip: TripMetric,
        appOfferFare: Double,
        surgeMultiplier: Double = 1.0
    ): FareBreakdown {
        // Strict trip distance multiplication only
        val distanceCost = trip.distanceKm * settings.pricePerKm
        val durationCost = trip.durationMinutes * settings.pricePerMinute
        val subtotal = settings.baseFare + distanceCost + durationCost
        val grossTrueFare = max(settings.minFare, subtotal * max(1.0, surgeMultiplier))

        // Platform commission cut
        val effectiveCommission = settings.commissionPercent.coerceIn(0.0, 50.0)
        val netDriverReceived = if (appOfferFare > 0.0) {
            appOfferFare * (1.0 - (effectiveCommission / 100.0))
        } else {
            grossTrueFare * (1.0 - (effectiveCommission / 100.0))
        }

        // Fare comparison
        val effectiveOffer = if (appOfferFare > 0.0) appOfferFare else grossTrueFare * 1.05
        val diff = effectiveOffer - grossTrueFare

        // Effective Rate Per KM (actual trip distance only)
        val ratePerKm = if (trip.distanceKm > 0.0) {
            effectiveOffer / trip.distanceKm
        } else {
            settings.pricePerKm
        }

        // Profitability evaluation
        val rating = when {
            effectiveOffer >= grossTrueFare * 1.10 -> ProfitRating.HIGH_PROFIT
            effectiveOffer >= grossTrueFare * 0.90 -> ProfitRating.ACCEPTABLE
            else -> ProfitRating.LOW_PROFIT
        }

        return FareBreakdown(
            calculatedTrueFare = roundTwoDecimals(grossTrueFare),
            appOfferFare = roundTwoDecimals(effectiveOffer),
            difference = roundTwoDecimals(diff),
            netDriverFare = roundTwoDecimals(netDriverReceived),
            profitRating = rating,
            ratePerKm = roundTwoDecimals(ratePerKm),
            currencySymbol = settings.currencySymbol
        )
    }

    private fun roundTwoDecimals(value: Double): Double {
        return (value * 100.0).roundToInt() / 100.0
    }
}
