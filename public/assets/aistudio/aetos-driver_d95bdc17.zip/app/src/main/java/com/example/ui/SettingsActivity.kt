package com.example.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.AetosApplication
import com.example.data.local.FareSettingsEntity
import com.example.databinding.ActivitySettingsBinding
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val repository = AetosApplication.instance.repository
        viewModel = ViewModelProvider(this, MainViewModel.Factory(repository))[MainViewModel::class.java]

        setupToolbar()
        populateCurrentSettings()
        setupSaveButton()
    }

    private fun setupToolbar() {
        binding.toolbarSettings.setNavigationOnClickListener {
            finish()
        }
    }

    private fun populateCurrentSettings() {
        lifecycleScope.launch {
            viewModel.settings.collectLatest { settings ->
                binding.etPricePerKm.setText(settings.pricePerKm.toString())
                binding.etBaseFare.setText(settings.baseFare.toString())
                binding.etPricePerMin.setText(settings.pricePerMinute.toString())
                binding.etMinFare.setText(settings.minFare.toString())
                binding.etCommissionRate.setText(settings.commissionPercent.toString())
                binding.etCurrency.setText(settings.currencySymbol)
            }
        }
    }

    private fun setupSaveButton() {
        binding.btnSaveSettings.setOnClickListener {
            val pricePerKm = binding.etPricePerKm.text.toString().toDoubleOrNull() ?: 2.80
            val baseFare = binding.etBaseFare.text.toString().toDoubleOrNull() ?: 5.00
            val pricePerMin = binding.etPricePerMin.text.toString().toDoubleOrNull() ?: 0.35
            val minFare = binding.etMinFare.text.toString().toDoubleOrNull() ?: 10.00
            val commission = binding.etCommissionRate.text.toString().toDoubleOrNull() ?: 20.0
            val currency = binding.etCurrency.text.toString().trim().ifEmpty { "$" }

            val updatedSettings = FareSettingsEntity(
                id = 1,
                baseFare = baseFare,
                pricePerKm = pricePerKm,
                pricePerMinute = pricePerMin,
                minFare = minFare,
                commissionPercent = commission,
                currencySymbol = currency
            )

            viewModel.saveSettings(updatedSettings)
            Toast.makeText(this, "Fare parameters updated successfully!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
