package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.CustomAreaEntity
import com.example.data.local.FareSettingsEntity
import com.example.data.local.RideLogEntity
import com.example.model.RideTelemetryState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map

class DriverRepository(private val dao: AppDao) {

    private val _liveTelemetry = MutableStateFlow<RideTelemetryState?>(null)
    val liveTelemetry: StateFlow<RideTelemetryState?> = _liveTelemetry.asStateFlow()

    fun updateLiveTelemetry(state: RideTelemetryState) {
        _liveTelemetry.value = state
    }

    val settingsFlow: Flow<FareSettingsEntity> = dao.getSettingsFlow().map {
        it ?: FareSettingsEntity()
    }

    suspend fun getSettingsSync(): FareSettingsEntity {
        return dao.getSettingsSync() ?: FareSettingsEntity()
    }

    suspend fun saveSettings(settings: FareSettingsEntity) {
        dao.insertOrUpdateSettings(settings)
    }

    val logsFlow: Flow<List<RideLogEntity>> = dao.getAllLogsFlow()

    suspend fun insertRideLog(state: RideTelemetryState) {
        val entity = RideLogEntity(
            appName = state.appName,
            timestamp = state.timestamp,
            pickupDistanceKm = state.pickup.distanceKm,
            pickupDurationMin = state.pickup.durationMinutes,
            tripDistanceKm = state.trip.distanceKm,
            tripDurationMin = state.trip.durationMinutes,
            appOfferFare = state.fare.appOfferFare,
            calculatedFare = state.fare.calculatedTrueFare,
            difference = state.fare.difference,
            rating = state.fare.profitRating.name,
            currency = state.fare.currencySymbol
        )
        dao.insertRideLog(entity)
    }

    suspend fun clearLogs() {
        dao.clearAllLogs()
    }

    val areasFlow: Flow<List<CustomAreaEntity>> = dao.getAllAreasFlow()

    suspend fun getAreasSync(): List<CustomAreaEntity> {
        return dao.getAllAreasSync()
    }

    suspend fun addArea(name: String, multiplier: Double, notes: String = "") {
        val area = CustomAreaEntity(
            name = name,
            surgeMultiplier = multiplier,
            notes = notes
        )
        dao.insertArea(area)
    }

    suspend fun deleteArea(area: CustomAreaEntity) {
        dao.deleteArea(area)
    }
}
