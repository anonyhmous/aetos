package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.AetosApplication
import com.example.MainActivity
import com.example.R
import com.example.databinding.FloatingWidgetLayoutBinding
import com.example.engine.FareCalculatorEngine
import com.example.model.FareBreakdown
import com.example.model.PickupMetric
import com.example.model.ProfitRating
import com.example.model.RideTelemetryState
import com.example.model.TripMetric
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.random.Random

class FloatingOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var binding: FloatingWidgetLayoutBinding? = null
    private var windowParams: WindowManager.LayoutParams? = null

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private val repository by lazy { AetosApplication.instance.repository }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundServiceWithNotification()
        initFloatingOverlay()
        observeTelemetry()
    }

    private fun startForegroundServiceWithNotification() {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, AetosApplication.CHANNEL_ID_OVERLAY)
            .setContentTitle(getString(R.string.app_name))
            .setContentText("Aetos HUD is active: Monitoring ride metrics & true fares")
            .setSmallIcon(R.drawable.ic_app_logo)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            }
            startForeground(NOTIFICATION_ID, notification, serviceType)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initFloatingOverlay() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val inflater = LayoutInflater.from(this)
        binding = FloatingWidgetLayoutBinding.inflate(inflater)
        floatingView = binding?.root

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        windowParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 150
        }

        setupDragListener()
        setupButtons()

        try {
            windowManager?.addView(floatingView, windowParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDragListener() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        binding?.headerDragBar?.setOnTouchListener { _, event ->
            val params = windowParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(floatingView, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun setupButtons() {
        binding?.ivCloseOverlay?.setOnClickListener {
            stopSelf()
        }

        binding?.btnSimulateNext?.setOnClickListener {
            simulateNextRide()
        }
    }

    private fun observeTelemetry() {
        serviceScope.launch {
            repository.liveTelemetry.collectLatest { state ->
                if (state != null) {
                    renderTelemetry(state)
                } else {
                    // Default preview data
                    simulateDefaultData()
                }
            }
        }
    }

    private fun renderTelemetry(state: RideTelemetryState) {
        val b = binding ?: return

        // 1. Isolated Pickup Metrics
        b.tvPickupDistance.text = String.format(java.util.Locale.US, "%.1f km", state.pickup.distanceKm)
        b.tvPickupTime.text = "${state.pickup.durationMinutes} min away"

        // 2. Isolated Trip Metrics
        b.tvTripDistance.text = String.format(java.util.Locale.US, "%.1f km", state.trip.distanceKm)
        b.tvTripDuration.text = "${state.trip.durationMinutes} mins"

        // 3. Calculated Fare vs App Offer
        val curr = state.fare.currencySymbol
        b.tvCalculatedFare.text = String.format(java.util.Locale.US, "%s%.2f", curr, state.fare.calculatedTrueFare)
        b.tvAppOfferFare.text = String.format(java.util.Locale.US, "Offer: %s%.2f", curr, state.fare.appOfferFare)

        val diff = state.fare.difference
        if (diff >= 0.0) {
            b.tvFareDifference.text = String.format(java.util.Locale.US, "+ %s%.2f (Surplus)", curr, diff)
            b.tvFareDifference.setTextColor(ContextCompat.getColor(this, R.color.accent_driver_green))
        } else {
            b.tvFareDifference.text = String.format(java.util.Locale.US, "- %s%.2f (Underpriced)", curr, kotlin.math.abs(diff))
            b.tvFareDifference.setTextColor(ContextCompat.getColor(this, R.color.alert_red))
        }

        b.tvRatePerKm.text = String.format(java.util.Locale.US, "Rate: %s%.2f/km", curr, state.fare.ratePerKm)
        b.tvAppSource.text = state.appName

        // 4. Profitability Badge
        when (state.fare.profitRating) {
            ProfitRating.HIGH_PROFIT -> {
                b.tvProfitabilityBadge.text = "PROFITABLE"
                b.tvProfitabilityBadge.setTextColor(ContextCompat.getColor(this, R.color.accent_driver_green))
            }
            ProfitRating.ACCEPTABLE -> {
                b.tvProfitabilityBadge.text = "FAIR"
                b.tvProfitabilityBadge.setTextColor(ContextCompat.getColor(this, R.color.accent_amber))
            }
            ProfitRating.LOW_PROFIT -> {
                b.tvProfitabilityBadge.text = "SKIP / LOW"
                b.tvProfitabilityBadge.setTextColor(ContextCompat.getColor(this, R.color.alert_red))
            }
        }
    }

    private fun simulateDefaultData() {
        serviceScope.launch {
            val settings = repository.getSettingsSync()
            val engine = FareCalculatorEngine(settings)
            val pickup = PickupMetric(1.2, 3, "1.2 km / 3 min away")
            val trip = TripMetric(8.5, 22, "8.5 km / 22 mins")
            val fare = engine.calculate(pickup, trip, 28.50, 1.0)
            val state = RideTelemetryState(
                appName = "Uber X",
                pickup = pickup,
                trip = trip,
                fare = fare
            )
            renderTelemetry(state)
        }
    }

    fun simulateNextRide() {
        serviceScope.launch {
            val settings = repository.getSettingsSync()
            val engine = FareCalculatorEngine(settings)

            val apps = listOf("Uber X", "InDrive", "Careem GO", "Bolt", "DiDi")
            val app = apps.random()

            val pickupKm = (5 + Random.nextInt(25)) / 10.0 // 0.5 - 3.0 km
            val pickupMin = (pickupKm * 2.5 + Random.nextInt(3)).toInt().coerceAtLeast(1)

            val tripKm = (30 + Random.nextInt(150)) / 10.0 // 3.0 - 18.0 km
            val tripMin = (tripKm * 2.2 + Random.nextInt(6)).toInt().coerceAtLeast(5)

            // Random fare offer from passenger/app
            val idealFare = settings.baseFare + (tripKm * settings.pricePerKm) + (tripMin * settings.pricePerMinute)
            val offerRatio = listOf(0.78, 0.95, 1.15, 1.30).random()
            val offerFare = (idealFare * offerRatio * 100).toInt() / 100.0

            val pickup = PickupMetric(pickupKm, pickupMin, "Pickup simulated")
            val trip = TripMetric(tripKm, tripMin, "Trip simulated")
            val fare = engine.calculate(pickup, trip, offerFare, 1.0)

            val state = RideTelemetryState(
                appName = app,
                pickup = pickup,
                trip = trip,
                fare = fare
            )

            repository.updateLiveTelemetry(state)
            repository.insertRideLog(state)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        floatingView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        floatingView = null
        binding = null
    }

    companion object {
        private const val NOTIFICATION_ID = 9021

        fun start(context: Context) {
            val intent = Intent(context, FloatingOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingOverlayService::class.java)
            context.stopService(intent)
        }
    }
}
