package com.example.engine

import android.graphics.Bitmap
import com.example.model.PickupMetric
import com.example.model.TripMetric
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class OcrProcessor {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun processFrame(bitmap: Bitmap): OcrResult = suspendCancellableCoroutine { continuation ->
        try {
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val lines = visionText.textBlocks.flatMap { it.lines.map { line -> line.text } }
                    val (pickup, trip) = TripMetricParser.parseRideDetails(lines)
                    val fareOffer = TripMetricParser.extractFareAmount(visionText.text)
                    continuation.resume(
                        OcrResult(
                            success = true,
                            pickup = pickup,
                            trip = trip,
                            fareOffer = fareOffer,
                            rawFullText = visionText.text
                        )
                    )
                }
                .addOnFailureListener { exc ->
                    continuation.resume(
                        OcrResult(
                            success = false,
                            pickup = PickupMetric(1.0, 3, "Error"),
                            trip = TripMetric(5.0, 15, "Error"),
                            fareOffer = 0.0,
                            rawFullText = exc.localizedMessage ?: "OCR failure"
                        )
                    )
                }
        } catch (e: Exception) {
            continuation.resume(
                OcrResult(
                    success = false,
                    pickup = PickupMetric(1.0, 3, "Exception"),
                    trip = TripMetric(5.0, 15, "Exception"),
                    fareOffer = 0.0,
                    rawFullText = e.localizedMessage ?: "OCR exception"
                )
            )
        }
    }

    fun release() {
        recognizer.close()
    }
}

data class OcrResult(
    val success: Boolean,
    val pickup: PickupMetric,
    val trip: TripMetric,
    val fareOffer: Double,
    val rawFullText: String
)
