package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [FareSettingsEntity::class, RideLogEntity::class, CustomAreaEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aetos_driver.db"
                )
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Populate default data asynchronously
                            CoroutineScope(Dispatchers.IO).launch {
                                val dao = getInstance(context).appDao()
                                dao.insertOrUpdateSettings(FareSettingsEntity())
                                dao.insertArea(
                                    CustomAreaEntity(
                                        name = "International Airport",
                                        surgeMultiplier = 1.35,
                                        notes = "High wait times and toll fees"
                                    )
                                )
                                dao.insertArea(
                                    CustomAreaEntity(
                                        name = "Downtown Business Center",
                                        surgeMultiplier = 1.20,
                                        notes = "Rush hour peak congestion"
                                    )
                                )
                                dao.insertRideLog(
                                    RideLogEntity(
                                        appName = "Uber X",
                                        timestamp = System.currentTimeMillis() - 15 * 60 * 1000,
                                        pickupDistanceKm = 1.4,
                                        pickupDurationMin = 4,
                                        tripDistanceKm = 9.2,
                                        tripDurationMin = 24,
                                        appOfferFare = 34.00,
                                        calculatedFare = 30.76,
                                        difference = 3.24,
                                        rating = "PROFITABLE",
                                        currency = "$"
                                    )
                                )
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
