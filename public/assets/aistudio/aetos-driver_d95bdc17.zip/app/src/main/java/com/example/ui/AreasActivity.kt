package com.example.ui

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.AetosApplication
import com.example.databinding.ActivityAreasBinding
import com.example.ui.adapter.AreaAdapter
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AreasActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAreasBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: AreaAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAreasBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val repository = AetosApplication.instance.repository
        viewModel = ViewModelProvider(this, MainViewModel.Factory(repository))[MainViewModel::class.java]

        setupToolbar()
        setupRecyclerView()
        setupAddZone()
        observeAreas()
    }

    private fun setupToolbar() {
        binding.toolbarAreas.setNavigationOnClickListener {
            finish()
        }
    }

    private fun setupRecyclerView() {
        adapter = AreaAdapter { areaToDelete ->
            viewModel.deleteArea(areaToDelete)
            Toast.makeText(this, "Zone '${areaToDelete.name}' removed", Toast.LENGTH_SHORT).show()
        }
        binding.rvAreas.layoutManager = LinearLayoutManager(this)
        binding.rvAreas.adapter = adapter
    }

    private fun setupAddZone() {
        binding.btnAddZone.setOnClickListener {
            val name = binding.etZoneName.text.toString().trim()
            val multStr = binding.etZoneMultiplier.text.toString().trim()
            val multiplier = multStr.toDoubleOrNull() ?: 1.25

            if (name.isEmpty()) {
                binding.tilZoneName.error = "Please enter a zone name or keyword"
                return@setOnClickListener
            }
            binding.tilZoneName.error = null

            viewModel.addArea(name, multiplier, "User configured surge zone")
            binding.etZoneName.text?.clear()
            binding.etZoneMultiplier.setText("1.30")
            Toast.makeText(this, "Surge Zone '$name' saved!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun observeAreas() {
        lifecycleScope.launch {
            viewModel.areas.collectLatest { areasList ->
                adapter.submitList(areasList)
                if (areasList.isEmpty()) {
                    binding.tvEmptyAreas.visibility = View.VISIBLE
                    binding.rvAreas.visibility = View.GONE
                } else {
                    binding.tvEmptyAreas.visibility = View.GONE
                    binding.rvAreas.visibility = View.VISIBLE
                }
            }
        }
    }
}
