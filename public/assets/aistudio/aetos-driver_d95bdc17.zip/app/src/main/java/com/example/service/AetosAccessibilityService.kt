package com.example.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.AetosApplication
import com.example.engine.FareCalculatorEngine
import com.example.engine.TripMetricParser
import com.example.model.RideTelemetryState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class AetosAccessibilityService : AccessibilityService() {

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)

    private val repository by lazy { AetosApplication.instance.repository }
    private var lastProcessedHash: Int = 0
    private var lastProcessTime: Long = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // Throttle rapid repeated events (minimum 400ms between scans)
        val now = System.currentTimeMillis()
        if (now - lastProcessTime < 400L) return

        val rootNode = rootInActiveWindow ?: return
        val packageName = event.packageName?.toString() ?: ""

        val textNodes = mutableListOf<String>()
        traverseNode(rootNode, textNodes)

        if (textNodes.isEmpty()) return

        val contentHash = textNodes.hashCode()
        if (contentHash == lastProcessedHash) return
        lastProcessedHash = contentHash
        lastProcessTime = now

        processExtractedText(packageName, textNodes)
    }

    private fun traverseNode(node: AccessibilityNodeInfo?, collected: MutableList<String>) {
        if (node == null) return

        node.text?.toString()?.trim()?.let {
            if (it.isNotEmpty()) collected.add(it)
        }

        node.contentDescription?.toString()?.trim()?.let {
            if (it.isNotEmpty() && !collected.contains(it)) collected.add(it)
        }

        for (i in 0 until node.childCount) {
            traverseNode(node.getChild(i), collected)
        }
    }

    private fun processExtractedText(packageName: String, texts: List<String>) {
        serviceScope.launch {
            val settings = repository.getSettingsSync()
            val areas = repository.getAreasSync()

            // 1. Parse isolated pickup vs trip metrics
            val (pickup, trip) = TripMetricParser.parseRideDetails(texts)
            val fullJoined = texts.joinToString(" ")
            val offerFare = TripMetricParser.extractFareAmount(fullJoined)

            // Check if alert corresponds to a ride request
            if (trip.distanceKm <= 0.0 && offerFare <= 0.0) {
                return@launch
            }

            // 2. Check for surge areas
            var surgeMultiplier = 1.0
            for (area in areas) {
                if (fullJoined.contains(area.name, ignoreCase = true)) {
                    surgeMultiplier = area.surgeMultiplier
                    break
                }
            }

            // 3. Compute accurate isolated fare
            val engine = FareCalculatorEngine(settings)
            val fare = engine.calculate(pickup, trip, offerFare, surgeMultiplier)

            val readableAppName = when {
                packageName.contains("uber", ignoreCase = true) -> "Uber Driver"
                packageName.contains("indriver", ignoreCase = true) || packageName.contains("mizink", ignoreCase = true) -> "InDrive"
                packageName.contains("careem", ignoreCase = true) -> "Careem Captain"
                packageName.contains("bolt", ignoreCase = true) -> "Bolt Driver"
                packageName.contains("didi", ignoreCase = true) -> "DiDi Driver"
                else -> "Ride Alert"
            }

            val state = RideTelemetryState(
                appName = readableAppName,
                timestamp = System.currentTimeMillis(),
                pickup = pickup,
                trip = trip,
                fare = fare,
                surgeMultiplier = surgeMultiplier
            )

            // 4. Stream to repository
            repository.updateLiveTelemetry(state)
            repository.insertRideLog(state)
        }
    }

    override fun onInterrupt() {
        // Handle interruption
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }
}
