package com.example.model

enum class ProfitRating {
    HIGH_PROFIT,
    ACCEPTABLE,
    LOW_PROFIT
}

data class PickupMetric(
    val distanceKm: Double,
    val durationMinutes: Int,
    val rawText: String
)

data class TripMetric(
    val distanceKm: Double,
    val durationMinutes: Int,
    val rawText: String
)

data class FareBreakdown(
    val calculatedTrueFare: Double,
    val appOfferFare: Double,
    val difference: Double,
    val netDriverFare: Double,
    val profitRating: ProfitRating,
    val ratePerKm: Double,
    val currencySymbol: String
)

data class RideTelemetryState(
    val appName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val pickup: PickupMetric,
    val trip: TripMetric,
    val fare: FareBreakdown,
    val surgeMultiplier: Double = 1.0
)
