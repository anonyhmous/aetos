package com.example.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.data.local.CustomAreaEntity
import com.example.databinding.ItemAreaBinding
import java.util.Locale

class AreaAdapter(
    private val onDeleteClick: (CustomAreaEntity) -> Unit
) : ListAdapter<CustomAreaEntity, AreaAdapter.AreaViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AreaViewHolder {
        val binding = ItemAreaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AreaViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AreaViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class AreaViewHolder(private val binding: ItemAreaBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: CustomAreaEntity) {
            binding.tvAreaName.text = item.name
            binding.tvAreaMultiplier.text = String.format(
                Locale.US,
                "Surge Multiplier: %.2fx%s",
                item.surgeMultiplier,
                if (item.notes.isNotEmpty()) " (${item.notes})" else ""
            )

            binding.btnDeleteArea.setOnClickListener {
                onDeleteClick(item)
            }
        }
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<CustomAreaEntity>() {
            override fun areItemsTheSame(oldItem: CustomAreaEntity, newItem: CustomAreaEntity): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: CustomAreaEntity, newItem: CustomAreaEntity): Boolean {
                return oldItem == newItem
            }
        }
    }
}
