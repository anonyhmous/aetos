package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.CustomAreaEntity
import com.example.data.local.FareSettingsEntity
import com.example.data.local.RideLogEntity
import com.example.data.repository.DriverRepository
import com.example.engine.FareCalculatorEngine
import com.example.model.PickupMetric
import com.example.model.RideTelemetryState
import com.example.model.TripMetric
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

class MainViewModel(private val repository: DriverRepository) : ViewModel() {

    val settings: StateFlow<FareSettingsEntity> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FareSettingsEntity())

    val logs: StateFlow<List<RideLogEntity>> = repository.logsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val areas: StateFlow<List<CustomAreaEntity>> = repository.areasFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val liveTelemetry: StateFlow<RideTelemetryState?> = repository.liveTelemetry

    fun saveSettings(settingsEntity: FareSettingsEntity) {
        viewModelScope.launch {
            repository.saveSettings(settingsEntity)
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    fun addArea(name: String, multiplier: Double, notes: String = "") {
        viewModelScope.launch {
            repository.addArea(name, multiplier, notes)
        }
    }

    fun deleteArea(area: CustomAreaEntity) {
        viewModelScope.launch {
            repository.deleteArea(area)
        }
    }

    fun simulateAlert() {
        viewModelScope.launch {
            val currentSettings = repository.getSettingsSync()
            val engine = FareCalculatorEngine(currentSettings)

            val apps = listOf("Uber X", "InDrive", "Careem GO", "Bolt Driver", "DiDi Fast")
            val selectedApp = apps.random()

            // Random realistic values
            val pickupDistance = (8 + Random.nextInt(25)) / 10.0 // 0.8 - 3.2 km
            val pickupDuration = (pickupDistance * 2.8).toInt().coerceAtLeast(2)

            val tripDistance = (40 + Random.nextInt(180)) / 10.0 // 4.0 - 22.0 km
            val tripDuration = (tripDistance * 2.4).toInt().coerceAtLeast(8)

            val idealFare = currentSettings.baseFare +
                    (tripDistance * currentSettings.pricePerKm) +
                    (tripDuration * currentSettings.pricePerMinute)

            val offerRatio = listOf(0.82, 0.94, 1.12, 1.35).random()
            val offerFare = (idealFare * offerRatio * 100).toInt() / 100.0

            val pickup = PickupMetric(pickupDistance, pickupDuration, "Simulated Pickup")
            val trip = TripMetric(tripDistance, tripDuration, "Simulated Trip")
            val fare = engine.calculate(pickup, trip, offerFare, 1.0)

            val state = RideTelemetryState(
                appName = selectedApp,
                timestamp = System.currentTimeMillis(),
                pickup = pickup,
                trip = trip,
                fare = fare
            )

            repository.updateLiveTelemetry(state)
            repository.insertRideLog(state)
        }
    }

    class Factory(private val repository: DriverRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
                return MainViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
