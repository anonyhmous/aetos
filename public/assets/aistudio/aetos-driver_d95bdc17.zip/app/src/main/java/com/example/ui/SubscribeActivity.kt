package com.example.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.databinding.ActivitySubscribeBinding

class SubscribeActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySubscribeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySubscribeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbarSubscribe.setNavigationOnClickListener {
            finish()
        }

        binding.btnActivateLicense.setOnClickListener {
            val code = binding.etLicenseKey.text.toString().trim()
            if (code.isNotEmpty()) {
                binding.tvSubStatus.text = "Pro License: Active (365 Days Remaining)"
                Toast.makeText(this, "License code '$code' verified & activated successfully!", Toast.LENGTH_LONG).show()
            } else {
                binding.tilLicenseKey.error = "Please enter your license key"
            }
        }
    }
}
