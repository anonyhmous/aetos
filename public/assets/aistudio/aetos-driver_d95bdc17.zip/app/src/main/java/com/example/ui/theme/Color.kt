package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BgSlatePrimary = Color(0xFF121826)
val SurfaceCard = Color(0xFF1E293B)
val AccentDriverGreen = Color(0xFF00E676)
val AccentCyanInfo = Color(0xFF00F0FF)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val AlertRed = Color(0xFFFF3B30)
val AccentAmber = Color(0xFFFFD600)

val Purple80 = AccentCyanInfo
val PurpleGrey80 = TextSecondary
val Pink80 = AccentDriverGreen
val Purple40 = BgSlatePrimary
val PurpleGrey40 = SurfaceCard
val Pink40 = AccentAmber
